---
title: "Red Notice"
author: "Bill Browder"
date: 2024-02-02
categories: ["History"]
tags: ["russia", "finance", "politics", "human-rights"]
description: "Part financial thriller, part human rights story. Browder built one of the largest hedge funds in Russia, then watched Putin's system destroy it."
showToc: false
---

Part financial thriller, part human rights story. Browder built one of the largest hedge funds in Russia, then watched Putin's system destroy it. The backstory to the Magnitsky Act.

## Observations

Removes the delusion that you can do long-term business with people you can't trust. Character comes out in the end. Stay away. The descent of Russia back into the depths of a moral vacuum is truly sad. What might have been.
